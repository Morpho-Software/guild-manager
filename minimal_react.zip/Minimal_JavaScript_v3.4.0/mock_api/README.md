# THE MOCK API

#### DOWNLOAD RESOURCE

https://www.dropbox.com/s/qlh4lsax9vqpqxi/minimal-api-master.zip?dl=0

---

#### SETUP GUIDE

https://docs-minimals.vercel.app/quick-start/mock-server
